from distutils.core import setup

setup(
    name='AnyTree',
    version='0.0.1',
    author='Florent JOUATTE',
    author_email='fjouatte@anybox.fr',
    packages=['anytree', 'anytree.test'],
    license='LICENSE.txt',
    description='Resolving dependencies tree',
    install_requires=[
        "openobject-library",
    ],
)
