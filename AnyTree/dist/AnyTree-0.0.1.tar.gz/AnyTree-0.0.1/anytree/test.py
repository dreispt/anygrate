import xmlrpclib
import oobjlib
import pprint

username = 'admin'  #the user
pwd = 'admin'       #the password of the user
dbname = 'ecox_db'  #the database

sock_common = xmlrpclib.ServerProxy ('http://localhost:8069/xmlrpc/common')
uid = sock_common.login(dbname, username, pwd)

#replace localhost with the address of the server
sock = xmlrpclib.ServerProxy('http://localhost:8069/xmlrpc/object')

models = ['res.company']


def get_ordre_import(models):
    ordre_models = []
    for model in models:
        if ordre_models.count(model) == 0:
            ordre_models.append(model)
            fields = sock.execute(dbname, uid, pwd, model, 'fields_get')
            for field in fields:
                if(fields[field]['type'] == 'many2one'):
                    related_model = fields[field]['relation']
                    if ordre_models.count(related_model) == 0:
                        ordre_models.append(related_model)
                    if models.count(related_model) == 0:
                        models.append(related_model)
    return ordre_models

ordre_models = get_ordre_import(models)

""" Method to find out the dependencies tree of the models """

def get_ordre_importation(model, seen):
    print('MODELE COURANT : ', model)
    res = []
    if seen is None:
        seen = set()
    seen.add(model)
    m2o = set()
    deps = set()
    fields = sock.execute(dbname, uid, pwd, model, 'fields_get')
    for field in fields:
        if fields[field]['type'] == 'many2one':
            m = fields[field]['relation']
            deps.add(m)
            # Cas des structures arborescentes (reflexives)
            if m not in seen:
                m2o.add(m)
                seen.add(m)
    # DEJA FILTRE AU DESSUS for m in m2o.difference(seen):
    print('DEPENDANCES : ', deps)
    print('')
    for m in m2o:
        res += get_ordre_importation(m, seen)
    res.append(model)
    return res

ordre_model_importation = get_ordre_importation('res.partner.address', None)

currency_data = {
    'name': 'Devise virtuelle 2',
    'symbol': 'DV',
    'rate': '2',
    'rate_ids': '1',
    'base': 'True',
    'company_id': '8',
}

print (ordre_model_importation)
